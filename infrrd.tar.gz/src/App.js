import React from 'react';
import './App.css';
import EmployeeManagement from './components/EmployeeManagement'

function App() {
  return (
    <div className="App">
      <EmployeeManagement />
    </div>
  );
}

export default App;
