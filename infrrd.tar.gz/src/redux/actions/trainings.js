import * as actions from './types';

const addTraining = (training) => ({
    type: actions.ADD_TRAINING,
    training
});

const updateTraining = (training) => ({
    type: actions.UPDATE_TRAINING,
    training
});

export default {
    addTraining,
    updateTraining
}
