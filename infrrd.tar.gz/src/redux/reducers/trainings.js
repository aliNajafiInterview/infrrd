import {
    ADD_TRAINING,
    UPDATE_TRAINING
} from '../actions/types';

const initialState = () => ({
    trainings: [],
    trainingId: 0
});

const trainingsReducer = (state = initialState(), action) => {
    const { type, training } = action;
    let newState = Object.assign({}, state);
    const { trainings } = newState;

    switch (type) {
        case ADD_TRAINING:
            let newTraining = Object.assign({ id: ++newState.trainingId }, training)
            trainings.push(newTraining);
            break;
        case UPDATE_TRAINING:
            let theTraining = trainings.find(t => t.id === training.id);
            theTraining = Object.assign(theTraining, training)
            break;
        default: break;
    }
    return newState;
};

export default trainingsReducer;