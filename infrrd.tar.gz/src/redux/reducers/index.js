import { combineReducers } from 'redux';

import trainingsReducer from './trainings';

const appReducers = combineReducers({
    trainingsReducer,
});

export default appReducers;