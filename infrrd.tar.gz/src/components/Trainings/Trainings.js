import React from 'react';
import propTypes from 'prop-types';
import {
    Button, ButtonToolbar, Modal
} from 'react-bootstrap'
import { connect } from 'react-redux';
import actions from '../../redux/actions/trainings';
import DatePicker from "react-datepicker";
import TimePicker from 'react-bootstrap-time-picker';
import moment from 'moment'
import { timeFromInt } from 'time-number';
import classNames from 'classnames'

import "react-datepicker/dist/react-datepicker.css";
import './styles.css'

const ERROR_BORDER = 'error-border';

class TrainingsComponent extends React.Component {

    constructor() {
        super();
        this.state = {
            showModal: false,
            add: false,
            edit: false,
            editTrainingId: '',
            newTraining: {},
            newTrainingMissingField: {}
        }
    }

    openEditTraining = ({ add, edit, id }) => {
        let newTraining;
        if (add) {
            newTraining = {
                name: '',
                description: '',
                department: '',
                duration: '',
                date: '',
                time: '',
                roomNumber: ''
            }
        } else if (edit) {
            const theTraining = this.props.trainings.find(t => t.id === id)
            newTraining = Object.assign({}, theTraining)
            this.setState({ editTrainingId: id })
        }
        this.setState({
            showModal: true,
            add: !!add,
            edit: !!edit,
            newTraining,
            newTrainingMissingField: {
                name: false,
                description: false,
                department: false,
                duration: false,
                date: false,
                time: false,
                roomNumber: false,
            }
        })
    }
    closeAdd = () => {
        this.setState({ showModal: false, newTrainingMissingField: {} })
    }

    setNewTrainingField = (varName, value) => {
        const { newTraining } = this.state;
        newTraining[varName] = value;
        this.setState({ newTraining })
    }

    formTextEntry = (varName, label) => {
        const { newTraining, newTrainingMissingField } = this.state;
        const setValue = event => {
            this.setNewTrainingField(varName, event.target.value)
        }
        const value = newTraining[varName];
        return <>
            <div className='row'>
                <div className='column'>
                    {label}
                </div>
                <div className='column' >
                    < input
                        className={classNames({
                            [ERROR_BORDER]: newTrainingMissingField[varName]
                        })}
                        type='text' value={value} onChange={setValue} />
                </div>
            </div>
        </>
    }

    formDateEntry = (varName, label) => {
        const { newTrainingMissingField, newTraining } = this.state;
        const { date } = newTraining;
        const setValue = date => {
            this.setNewTrainingField(varName, date)
        }
        return <>
            <div className='row'>
                <div className='column'>
                    {label}
                </div>
                <div className='column'>
                    <DatePicker
                        className={classNames({
                            [ERROR_BORDER]: newTrainingMissingField[varName]
                        })}
                        selected={date}
                        onChange={setValue}
                    ></DatePicker>
                </div>
            </div>
        </>
    }

    formTimeEntry = (varName, label, placeholder) => {
        const { newTraining, newTrainingMissingField } = this.state;
        const { time } = newTraining;
        const setValue = time => {
            this.setNewTrainingField(varName, time)
        }
        return <>
            <div className='row'>
                <div className='column'>
                    {label}
                </div>
                <div className='column'>
                    <TimePicker
                        className={classNames({
                            [ERROR_BORDER]: newTrainingMissingField[varName]
                        })}
                        start='8:00'
                        end='19:00'
                        step={30}
                        onChange={setValue}
                        value={time}
                    ></TimePicker>
                </div>
            </div>
        </>
    }

    trainingModal = () => {
        const { showModal, add, edit } = this.state;
        let title;
        if (add) {
            title = 'Add Training'
        } else if (edit) {
            title = 'Update Training'
        }
        return < Modal show={showModal} onHide={this.closeAdd} >
            <Modal.Header >
                <Modal.Title>{title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className='add-training-form'>
                    {this.formTextEntry('name', 'Training Name')}
                    {this.formTextEntry('description', 'Training Description')}
                    {this.formTextEntry('department', 'Department')}
                    {this.formTextEntry('duration', 'Duration')}
                    {this.formDateEntry('date', 'Date')}
                    {this.formTimeEntry('time', 'Time')}
                    {this.formTextEntry('roomNumber', 'Meeting Room Number')}
                </div>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={this.closeAdd}>
                    Cancel
                </Button>
                <Button variant="primary" onClick={this.addTraining}>
                    Save
                </Button>
            </Modal.Footer>
        </Modal >
    }

    addTraining = () => {
        const { newTraining, add, edit, newTrainingMissingField } = this.state;
        const mandatoryFields = [
            'name',
            'department',
            'duration',
            'date',
            'time',
            'roomNumber'
        ]
        let ok = true;
        mandatoryFields.forEach(key => {
            const field = newTraining[key];
            if (field === '') {
                ok = false;
                newTrainingMissingField[key] = true;
            } else {
                newTrainingMissingField[key] = false;
            }
        })
        if (ok) {
            if (add) {
                this.props.addTraining(this.state.newTraining)
            } else if (edit) {
                this.props.updateTraining(this.state.newTraining)
            }
            this.closeAdd();
        } else {
            this.setState({ newTrainingMissingField })
        }
    }

    editTraining = id => {
        this.openEditTraining({ edit: true, id })
    }

    listOfTrainings = () => {
        const { trainings } = this.props;
        if (trainings.length === 0) {
            return <div>
                No training available
            </div>
        }
        return <table className='training-list'>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Department</th>
                    <th>Duration</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Room Number</th>
                </tr>
            </thead>
            <tbody>
                {trainings.map(training => {
                    const { id, name, description, department, duration, date, time, roomNumber } = training
                    return <tr key={id} onClick={() => this.editTraining(id)}>
                        <td>{name}</td>
                        <td>{description}</td>
                        <td>{department}</td>
                        <td>{duration}</td>
                        <td>{moment(date).format('MM/DD/YYYY')}</td>
                        <td>{timeFromInt(time)}</td>
                        <td>{roomNumber}</td>
                    </tr>
                })
                }
            </tbody></table >
    }

    render() {
        return <div >
            <ButtonToolbar>
                <Button variant="secondary" onClick={() => this.openEditTraining({ add: true })}>Add Training</Button>
            </ButtonToolbar>
            {this.trainingModal()}
            {this.listOfTrainings()}
        </div>
    }
}

TrainingsComponent.propTypes = {
    trainings: propTypes.array.isRequired,
    addTraining: propTypes.func.isRequired,
    updateTraining: propTypes.func.isRequired
}

// =================================================================
//
// =================================================================

const { addTraining, updateTraining } = actions;

const mapStateToProps = (state, ownProps) => {
    const { trainingsReducer } = state;
    const { trainings } = trainingsReducer
    return {
        trainings
    }
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        addTraining: (training) => {
            dispatch(addTraining(training))
        },
        updateTraining: (training) => {
            dispatch(updateTraining(training))
        },
    }
}

const Trainings = connect(
    mapStateToProps,
    mapDispatchToProps,
)(TrainingsComponent);

export default Trainings;