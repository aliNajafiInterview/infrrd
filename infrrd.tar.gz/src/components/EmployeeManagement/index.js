import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route,
} from "react-router-dom";
import { Navbar, Nav, FormControl, Button } from 'react-bootstrap';
import './styles.css'

import Trainings from '../Trainings/Trainings'

class EmployeeManagement extends React.Component {
    render() {
        return <Router>
            <div>
                <Navbar bg="light" variant="light">
                    <Nav className="emp-nav">
                        <Navbar.Brand className='navbar' href="/">Emplolyee Traning Management</Navbar.Brand>
                        <Nav.Link className='navbar' href="/trainings">Trainings</Nav.Link>
                        <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                        <Button variant="outline-primary">Search</Button>
                    </Nav>
                </Navbar>
                <Switch>
                    <Route path="/trainings">
                        <Trainings />
                    </Route>
                </Switch>
            </div>
        </Router>

    }
}

export default EmployeeManagement;